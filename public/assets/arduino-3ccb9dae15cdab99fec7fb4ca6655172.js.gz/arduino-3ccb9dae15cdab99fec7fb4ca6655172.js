(function() {
  var IndexCtrl;

  IndexCtrl = function($scope) {
    $scope = "Myblog";
  };

  IndexCtrl.$inject = ["$scope"];

}).call(this);
