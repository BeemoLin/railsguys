(function() {
  this.IndexCtrl = function($scope) {
    return $scope.title = "My blog";
  };

}).call(this);
