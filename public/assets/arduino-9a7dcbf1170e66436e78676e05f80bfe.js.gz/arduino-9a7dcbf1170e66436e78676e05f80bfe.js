(function() {
  controller({
    "IndexCtrl": ['$scope', function($scope) {}, $scope.title = "My Blog"]
  });

}).call(this);
